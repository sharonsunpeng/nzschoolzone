Enrolment Scheme Master
Version as at 13/04/2022

Edits in this version received over Term 1 2022:

Abandoned schemes to delete / remove zone
125 	Raglan Area School (never implemented)

Written Description Only
625	Tamaoho School
340	Cashmere High School
315	St Bede’s College 

New, amended and redrawn zones to be added
38	Westlake Girls' High School	AK	redrawn 		
565	Stonefields School	AK	redrawn	
593	Te Uho o Te Nikau Primary School	AK	redrawn
1306	Helensville School	AK	redrawn
1326	Kaukapakapa School	AK	redrawn
1421	Papakura Central School	AK	redrawn
1455	Puni School	AK	redrawn
1564	Wesley Intermediate	AK 	new
1579	Wymondley Road School	AK	new
1791	Lynmore Primary School	RO	amended
2112	Barton Rural School	SI	amended
2612	Mayfair School	HM	amended
2927	Ngaio School	WN	redrawn
3354	Governors Bay School	SI	new
3479	Queenspark School	SI	amended
3790	Opoho School	SI	new
3844	The Terrace School (Alexandra)	SI	amended
3966	Invercargill Middle School	SI	amended
4006	Rimu School	SI	amended
4028	Thornbury School	amended
2021	Te Rerenga School	HM	new
2262	Waitoriki School	WN	new
2382	Kiwitea School	WN	new	

