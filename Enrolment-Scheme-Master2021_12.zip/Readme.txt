Enrolment Scheme Master
Version as at 06/12/2021

Edits in this version received over part of the second half of Term 4 2021:

Abandoned schemes to delete / remove zone
NIL

Written Description Only
NIL

Redrawn zones to be added (no descriptions)
1208	Ardmore School	Redrawn	

New and amended zones to be added
1526 	Tamaki School	New
3396	Kirkwood Intermediate 	New
3379 	Hoon Hay School	Amended

