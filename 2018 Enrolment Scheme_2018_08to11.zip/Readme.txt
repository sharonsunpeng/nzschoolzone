Enrolment Scheme Master
Version as at 30/11/2018

Edits in this version Aug Sept Oct and Nov 2018:

New / Amended

251	Heretaunga College	WN	20180905	20181015	251	Redrawn
399	Central Southland College	SI	20180820	20190101	399	New
1720	Forest Lake School	HM	20150626	20190128	1720	Redrawn
1863	Omokoroa School	HM	20070418	20070418	1863	Redrawn
2208	Oakura School	WN	20040519	20180821	2208	Redrawn
2572	Havelock North Intermediate	HM	20040121	20181112	2572	Redrawn
2828	Corinna School	WN	20180906	20190127	2828	New
2936	Opaki School	WN	20040810	20040810	2936	Redrawn
3036	Tawhai School	WN	20180911	20190204	3036	New
3046	Tokomaru School	WN	20181024	20181024	3046	New
3346	Gilberthorpe School	SI	20180724	20181015	3346	New
3357	Greendale School	SI	20180919	20191015	3357	New
579	Knights Stream School	SI	20180823	20190101	579	New
3385	Isleworth School	SI	20180910	20190101	3385	New
25	Orewa College	AK	20040922	20190101	25	New
3700	Abbotsford School	SI	20051215	20051215	3700	Redrawn
3707	Fenwick School	SI	20071030	20071030	3707	Redrawn
3733	East Taieri School	SI	20070115	20070115	3733	Redrawn
3795	Outram School	SI	20080307	20080307	3795	Redrawn
3817	Sawyers Bay School	SI	20180914	20181214	3817	New
3859	Wakari School	SI	20180911	20181211	3859	New
3864	Weston School	SI	20070308		3864	Redrawn
6941	Endeavour School	HM	20180214	20190101	6941	Amended
1320	Huapai District School	AK	20180730	20190101	1320	Amended
254	Mana College	WN	20181114	20190101	254	New
2214	Omata School	HM	20071218	20181205	2214	Amended
1884	Pahoia School	HM	20070418	20070418	1884	Redrawn
2806	Bellevue School (Newlands)	WN	20181024	20190128	2806	New
2925	Newlands School	WN	20181024	20190128	2925	Amended
2946	Papakowhai School	WN	20180711	20190101	2946	Amended
2947	Paparangi School	WN	20181024	20190128	2947	New
2979	Rewa Rewa School	WN	20181024	20190128	2979	New
3281	Ashburton Borough School (Y1-6)	SI	20181015	20190101	3281001	New (Year 1-6 zone)
3281	Ashburton Borough School (Y7&8)	SI	20181015	20190101	3281002	New (Year 7&8 zone)
1994	Tauriko School	HM	20150626	20181101	1994	Amended
774	Matua Ngaru School	AK	20180501	20190101	774	New
1990	Tauranga Intermediate	HM	20030627	20180101	1990	Amended
593	Te Uho o Te Nikau Primary School	AK	20180426	20190101	593	New
780	Te Ao Marama School	HM	20170316	20190101	780	New
1686	Arataki School	HM		20190101	1686	New
1747	Horsham Downs School	HM	20091218	20180723	1747	Redrawn
3577	Wairakei School (Christchurch)	SI	20180831	20190101	3577	New
485	Taumata School	HM	20171221	20190101	485	New
1972	Tahuna School	HM	20181114	20190128	1972	New
2046	Waerenga School	HM	20180918	20181015	2046	New
2091	Whitiora School	HM	20180910	20190128	2091	New
4135	St Mark's School (Christchurch)	SI	20180621	20180621	4135	New
2839	Fairhall School	SI	19940101	19991122	2839	Redrawn
5	Kerikeri High School	AK	20021206	20021206	5	Redrawn
43	Massey High School	AK	20020930	20180101	43	Ammended


Abandoned

1627	St Paul's School (Richmond)	SI	20051215	20051215	1627	Abandoned
2117	Fernworth Primary School	SI	20070411	20070411	2117	Abandoned

