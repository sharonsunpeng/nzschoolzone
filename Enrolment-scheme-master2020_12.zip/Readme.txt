Enrolment Scheme Master
Version as at 03/12/2020

Edits in this version received/implemented over Term 3/4 2020:

No desc attached
Nil

Abandoned schemes to delete
Nil

Written Desc only to load
1731 	Hamilton East School
1760	Kaipaki School
26 	Kaipara College
335 	Middleton Grange School
341 	Hillview Christian School
418	Rangiora New Life School
710	Rolleston Christian School


New and amended schemes to load
57	Tamaki College	AK	20200907	20210101	Secondary	57	New
82	Aidanfield Christian School	SI	20081218	20081215	Composite	82	Amended
217	Napier Girls' High School	HM	20060913	20060913	Secondary	217	Amended
1218	Bairds Mainfreight Primary School	AK	20201102	20210503	Contributing	1218	New
1296	Glenfield Primary School	AK	20201012	20210503	Contributing	1296	New
1305	Hay Park School	AK	20201105	20210503	Contributing	1305	New
1345	Mangatawhiri School	AK	20201020	20210503	Full Primary	1345	New
1350	Manuka Primary School	AK	20201012	20210503	Contributing	1350	New
1361	Marlborough School	AK	20201012	20210503	Contributing	1361	New
1368	May Road School	AK	20201105	20210503	Contributing	1368	New
1400	Onepoto School	AK	20201120	20210503	Contributing	1400	New
1565	Wesley Primary School	AK	20201105	20210503	Contributing	1565	New
1701	Cambridge Middle School	HN	20200805	20210127	Restricted C	1701	New
1889	Paterangi School	HM	20201030	20210127	Full Primary	1889	New
1898	Pokuru School	HM	20201030	20210127	Contributing	1898	New
1974	Tainui Full Primary School	HM	20201030	20210127	Full Primary	1974	New
1983	Tatuanui School	HM	20200626	20201012	Contributing	1983	New
2462	Taonui School	WN	20201023	20200101	Fully Primar	2462	New
2840	Featherston School	WN	20201019	20210201	Full Primary	2840	New
2980	Ridgway School	WN	20201028	20210201	Full Primary	2980	New
3572	Waimataitai School	SI	20201116	20210101	Full Primary	3572	New
1212	Avondale Intermediate	AK	20030211	20200219	Intermediate	1212	Amendment
3464	Ouruhia Model School	SI	20060703	20210101	Full Primary	3464	Amendment
3484	Redwood School (Christchurch)	SI	20040824	20210101	Contributing	3484	Amendment
3585	Weedons School	SI	20040906	20201030	Full Primary	3585	Amendment
1570	Weymouth School	AK	20030211	20210101	Contributing	1570	Amendment
584	West Rolleston Primary School	SI	20150506	20210101	Full Primary	584	Amendment
6967	Lemonwood Grove School	SI	20160817	20210101	Full Primary	6967	Amendment
6980	Clearview Primary	SI	20090928	20210101	Full Primary	6980	Amendment
3488	Rolleston School	SI	20030521	20210101	Full Primary	3488	Amendment
