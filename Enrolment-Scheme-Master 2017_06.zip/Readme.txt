Enrolment Scheme Master
Version as at 02/06/2017
Includes Special Temporary Enrolment Schemes in Chch

Edits in this version June 2017:

New / Ammended

3415	Linwood North School	SI	20170519	Contributing	New Scheme
3187	Clifton Terrace School	SI	20161212	Contributing	New Scheme
3811	Romahapa School	SI	20170403	Full Primary	New Scheme
3209	Nelson Central School	SI	20170505	Contributing	Ammendment
2010	Te Mata School (Raglan)HM	20120413	Full Primary	New Scheme

Abandoned

