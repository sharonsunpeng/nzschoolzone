Enrolment Scheme Master
Version as at 11/12/2015
Includes Special Temporary Enrolment Schemes in Chch

Edits in this version to:

December:

1577	Woodhill School 		Abandoned	AK
2544	Awapuni School			Abandoned	HM

225 	Woodford House 			Ammended	HM
1760	Kaipaki School			New		HM
1731	Hamilton East School		New		HM
1837	Mt Maunganui Intermediate	New		HM
1994 	Tauriko School			New 		HM
1870	Oropi School			New		HM
1306	Helensville School		New		AK
1224 	Beachlands School		New		AK
1392	Newton Central School		Ammended	AK
2365	Hokowhitu School		New		WN
654	Rolleston College 		New for 2017	SI
230	Lindisfarne College		Ammended	HM
2546	Bledisloe School		Ammended	HM
2573	Havelock North Primary School	Ammended	HM
2590	Lucknow School			Ammended	HM
2687	Taradale Intermediate		Ammended	HM
2697	Te Mata School (Havelock North)	Ammended	HM
2711	Twyford School			Ammended	HM
710	Rolleston Christian School	New		SI
1893	Pekarau	School			Ammended	HM
2002	Te Awamutu School		Ammended	HM
1989	Taupo School			Ammended	HM

