Enrolment Scheme Master
Version as at 09/12/2019

Edits in this version received Term 3 and 4 2019:

New / Amended

SchID	PolyID	SchName			Office 	Approved	Effective	Type	POly ID Comment

268	Newlands College	WN	20040505	20140625	Secondary	368	Redrawn
1387	Murrays Bay School	AK	20111013	20111013	Contributing	1387	Redrawn
2361	Gonville School	WN	20190910	20200101	Contributing	2361	New
2418	Central Normal School	WN	20040817	20190128	Contributing	2418	Redrawn
2575	Heretaunga Intermediate	HM	20190812	20200127	Contributing	2575	New
2806	Bellevue School (Newlands)	WN	20181024	20190128	Contributing	2806	Redrawn
2812	Bohally Intermediate	SI	20190814	20191014	Intermediate	2812	New
2924	Newlands Intermediate	WN	20171211	20180301	Intermediate	2924	Redrawn
26	Kaipara College	AK	20190808	20200101	Secondary	26	New
2925	Newlands School	WN	20181024	20190128	Contributing	2925	Redrawn
2947	Paparangi School	WN	20181024	20180128	Contributing	2947	Redrawn
2979	Rewa Rewa School	WN	20181024	20190128	Contributing	2979	Redrawn
1725	Glenview School	HM	20190626	20181014	Contributing	1725	New
3283	Ashburton Netherby School	SI	20190924	20200101	Contributing	3283	New
1838	Mount Maunganui Primary School	HM	20080430	20080430	Contributing	1838	Redrawn
3214	Ranzau School	SI	20180501	20180605	Contributing	3214	New
1940	Silverdale Normal School	HM	20190806	20191014	Contributing	1940	New
2001	Te Awamutu Intermediate	HM	20190904	20200127	Intermediate	2001	New
2074	Walton School	HM	20190822	20200127	Contributing	2074	New
308	Amuri Area School (Year 1-6)	SI	20190910	20191014	Composite	308001	New
308	Amuri Area School (Year 7-8)	SI	20190910	20191014	Composite	308002	New
308	Amuri Area School (Year 9-15)	SI	20190910	20191014	Composite	308003	New
6967	Lemonwood Grove School	SI	20160817	20191014	Full Primary	6967	minor amend
6980	Clearview Primary	SI	20090928	20191014	Full Primary	6980	minor amend
3493	Te Ara Maurea Roydvale School	SI	20100412	20200101	Contributing	3493	amendment for 2020
334	Riccarton High School	SI	19990616	20200101	Secondary	334	amendment for 2020
316	Papanui High School	SI	20060502	20200101	Secondary	316	amendment for 2020
320	Mairehau High School	SI	20190626	20200101	Secondary	320	New
337	Linwood College (Year 7&8)	SI	20190620	20200101	Secondary	337001	New
337	Linwood College (Year 9-15)	SI	20190620	20200101	Secondary	337002	New
339	Hillmorton High School (Year 7&8)	SI	20190710	20200101	Secondary	339001	New
339	Hillmorton High School (Year 9-15)	SI	20190710	20200101	Secondary	339002	New
704	Haeata Community College (Year 1-8)	SI	20190627	20200101	Composite	704001	New
704	Haeata Community College (Year 9-15)	SI	20190627	20200101	Composite	704002	New
319	Burnside High School	SI	19990604	20200101	Secondary	319	amendment for 2020
319	Burnside High School	SI	19990604	20220101	Secondary	319002	amendment for 2022
352	Geraldine High School (Year 7&8)	SI	20190816	20200101	Secondary	352001	New
352	Geraldine High School (Year 9-15)	SI	20190816	20200101	Secondary	352002	New
3413	Linwood Avenue School	SI	20190808	20191014	Contributing	3413	New
572	Te Matauru Primary	SI	20190613	20200101	Full Primary	572	New, Sch opening Jan 2020
3454	Omihi School	SI	20190329	20190429	Full Primary	3454	New
3461	Our Lady of the Assumption School (Chch)	SI	20181005	20181005	Full Primary	3461	New
2244	Stratford Primary School	WN	20190319	20190429	Contributing	2244	New
1785	Kuratau School	HM	20191018	20200101	Full Primary	1785	New
1987	Taupiri School	HM	20191030	20200127	Full Primary	1987	New
2810	Birchville School	WN	20191105	20200101	Contributing	2810	New
1991	Tauranga Primary School	HM	20191030	20200101	Contributing	1991	Ammended
2418	Central Normal School	WN	20040817	20190128	Contributing	2418	Redrawn
2350	Cloverlea School	WN	20191120	20200203	Contributing	2350	New 
2361	Gonville School	WN	20190910	20200101	Contributing	2361	New		
2220	Pembroke School	WN	20191106	20200127	Full Primary	2220	New
2244	Stratford Primary School	WN	20190319	20190429	Contributing	2244	New
91	Mangere College	AK	20191011	20200101	Secondary	91	New
1521	Swanson School	AK	20140505	20140505	Full Primary	1521	Redrawn





Abandoned enrolment schemes 
2844 	Fraser Crescent School	abandoned on 09/09/2019
2168	Frankley School		abandoned on 06/06/2018
189	Whanganui High School	abandoned on 14/12/2018


