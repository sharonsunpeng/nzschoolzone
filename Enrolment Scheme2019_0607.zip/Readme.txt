Enrolment Scheme Master
Version as at 11/07/2019

Edits in this version received June and July:

New / Amended

SchID	PolyID	SchName			Office 	Approved	Effective	Type	Comment

585	585	Ararira Springs Primary	SI	20180221	20190101	Full Primary	New
3450	3450	Oaklands School	SI	20050419	20190116	Full Primary	ammended
3366	3366	Halswell School	SI	20030122	20190116	Full Primary	ammended
3271	3271	Addington School	SI	20181220	20190101	Contributing	New
3496	3496	Russley School	SI	20071012	20190101	Full Primary	Amend
3332	3332	Duvauchelle School	SI	20190116	20190429	Contributing	New
1897	1897	Pirongia School	HM	20081028	20190416	Full Primary	Amendment
1894	1894	Pillans Point School	HM	20030714	20190416	Contributing	More Accurate drawing
2877	2877	Kelson School	WN	20060920	20190622	Contributing	Amendment
2077	2077	Westbrook School	HM	20120322	20190429	Contributing	Amendment
1224	1224	Beachlands School	AK	20151109	20190511	Full Primary	Amendment
1357	1357	Maraetai Beach School	AK	20190506	20190603	Full Primary	New Scheme
102	102	Rosehill College	AK	20050120	20190627	Secondary	Amendment
44	44	Waitakere College	AK	20040202	20040202	Secondary	Clarification
2543	2543	Arthur Miller School	HM	20130702	20190624	Contributing	Amendment
1691	1691	Awakeri School	HM	20030922	19991220	Full Primary	More accurate Drawing
1228	1228	Birkdale Intermediate School	AK	20190625	20200101	Intermediate	New
3778	3778	Elmgrove School	SI	20190516	20191014	Contributing	New
2563	2563	Frimley School	HM	20040426	20040426	Contributing	More accurate drawing
1295	1295	Glenfield Intermediate School	AK	20190625	20200101	Intermediate	New
2578	2578	Te Kura O Hiruharama School	HM	20030922	20191014	Full Primary	Amendment
1394	1394	Northcote Intermediate School	AK	20190625	20200101	Intermediate	New
1403	1403	Oranga School	AK	20190618	20191014	Full Primary	New
747	747	Te Kura O Take Karara	SI	20190530	20200101	Contributing	New
1555	1555	Wairau Intermediate School	AK	20190625	20200101	Intermediate	New
1167	1167	Wanaka Primary School	SI	20190604	20200101	Contributing	New


Abandoned
None


