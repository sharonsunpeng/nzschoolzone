Enrolment Scheme Master
Version as at 08/12/2017
Includes Special Temporary Enrolment Schemes in Chch

Edits in this version December 2017:

New / Ammended

346	Darfield High School (2018 Year 11-13)	SI	20060911	20060911	Secondary		346002	Ammendment
347	Lincoln High School (2018 Year 11-13)	SI	20121206	20130101	Secondary		347002	Ammended 2016 and Years 10-13 in 2017
347	Lincoln High School (2018 Year 9-10)	SI	20010727	20170101	Secondary		347001	2017 Year 9 only
3057	Waikawa Bay School	SI	20131202	20140203	Contributing		3057	Redrawn simple
138	Hillcrest High School	HM	20091222	20091222	Secondary		138	Simplified
1989	Taupo School	HM	20120924	20160101	Contributing		1989	Redrawn simplified
2978	Renwick School	SI	20121012	20120201	Full Primary		2978	Simplified
346	Darfield High School (2018 Year 9-10)	SI	20060911	20170101	Secondary		346001	Ammended for 2018 simplified
1080	Parua Bay School	AK	20170621	20180101	Full Primary		1080	New Scheme simplified
1765	Katikati Primary School	HM	20170802	20170925	Contributing		1765	Simplified
3839	Tahuna Normal Intermediate	SI	20170918	20171201	Intermediate		3839	New simplified
1112	Bay of Islands International Academy	AK	20150623	20150805	Full Primary		1112	Redrawn simplified
312	Rangiora High School	SI	20060822	20120619	Secondary		312	Simplified
6759	Snells Beach Primary School	AK	20080718	20080612	Contributing		6759	Simplified
2981	Riverlands School	SI	19991122	20130101	SI		2981	Simplified
3747	Hawea Flat School	SI	20071203	20150420	Contributing		3747	Simplified
3938	Hauroko Valley Primary School	SI	20170727	20170129	Contributing		3938	Redrawn simplified
3236	Westport South School	SI	20120925	20130128	Full Primary		3236	Simplified
3567	Waihao Downs School	SI	20161208	20170308	Full Primary		3567	New Scheme simplified
3392	Kaikoura Suburban School	SI	20030225	20130923	Contributing		3392	Simplified
380	St Hildas Collegiate	SI	20050406	20050406	Secondary		380	Simplified
386	Columba College	SI	20050406	20050406	Composite		386	Simplified
4117	Liberton Christian School	SI	20050406	20050406	Full Primary		4117	Simplified
6948	Albany Junior High School	AK	20120726	20120716	Secondary		6948	Simplified
563	Albany Senior High School	AK	20120726	20120716	Secondary		563	Simplified
167	Taupo-nui-a-Tia College	HM	20171117	20180101	Secondary		167	New
1406	Orewa North School	AK	20171127	20180101	Contributing		1406	New
43	Massey High School	AK	20020930	20180101	Secondary		43	Ammended
1716	Fairfield Primary School	HM	20171123	20180430	Contributing		1716	New
1034	Kerikeri Primary School	AK	20070716	20180101	Contributing		1034	Ammended
7	Okaihau College	AK	20021218	20021218	Secondary		7	Redrawn
1282	Gladstone School (Auckland)	AK	20060925	20180129	Contributing		1282	Redrawn
106	Tuakau College	AK	20171130	20180201	Secondary		106	New
2337	Ashhurst School	WN	20171119	20180129	Full Primary		2337	New
2358	Foxton Beach School	WN	20171108	20180129	Full Primary		2358	New
3502	Sheffield Contributing School	SI	20171207	20171207	Contributing		3502	New
2926	Newtown SchoolL	WN	20171127	20180129	Contributing		2916	New
1852	Ngongotaha School	HM	20171207	20180129	Contributing		1852	New
6963	Papamoa College	HM	20171207	20180101	Secondary		6963	Ammended
2970	Rangikura School	WN		20180128	Full Primary		2970	New


Abandoned

Nil 